lib/ holds unmodified Debian 12 (bookworm) i386 runtime libraries: GNU C Library (LGPL-2.1+),
libX11 and friends (MIT/X11), ALSA lib and PulseAudio client (LGPL-2.1+), systemd libudev (LGPL-2.1+),
D-Bus (AFL-2.1/GPL-2+), libdrm (MIT). Sources: https://sources.debian.org/ (packages listed in
packages.txt). SDL3 is zlib-licensed (SDL3-LICENSE.txt); FreeType is linked statically (FTL).
